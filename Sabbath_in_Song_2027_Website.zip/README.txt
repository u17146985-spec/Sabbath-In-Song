# Sabbath in Song 2027 Website

## Files
- index.html — main website
- style.css — design and responsive styling

## Free launch option: GitHub Pages
1. Create a free account at GitHub.
2. Create a new **Public** repository, e.g. `sabbath-in-song`.
3. Upload `index.html` and `style.css`.
4. Open the repository's **Settings → Pages**.
5. Under deployment, choose **Deploy from a branch**.
6. Select `main` and `/ (root)`, then Save.
7. GitHub will provide your free website address.

## What to customise
- Replace the text logo in `index.html` with your official Sabbath in Song logo.
- Replace the programme placeholders with the final programme.
- Add artist names and photographs.
- Replace the registration button with your Google Forms registration link.
- Replace the gallery placeholders with event photographs.

The site is already responsive for phones, tablets and computers.
